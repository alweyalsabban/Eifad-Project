import React from "react";
import { FcGoogle } from "react-icons/fc";
import { FaLinkedin } from "react-icons/fa";

function ScoialMeadia() {
  const onGoogle = () => {
    //window.open("/api/auth/login/google", "popup", "width=500,height=600");
    window.location.href = "/api/auth/login/google";
  };
  const onlinkedin = () => {
    //window.open("/api/auth/login/linkedin", "popup", "width=500,height=600");
    window.location.href = "/auth/login/linkedin";
  };

  return (
    <div className="flex items-center justify-around w-full max-w-90 m-auto mt-6">
      <FcGoogle size={40} onClick={onGoogle} className="hover:cursor-pointer" />

      <FaLinkedin
        size={40}
        color="blue"
        onClick={onlinkedin}
        className="hover:cursor-pointer"
      />
    </div>
  );
}

export default ScoialMeadia;
